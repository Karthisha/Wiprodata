﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementSystem
{
    public class Library
    {
        public List<Book> Books { get; private set; }
        public List<Borrower> Borrowers { get; private set; }

        public Library()
        {
            Books = new List<Book>();
            Borrowers = new List<Borrower>();
        }

        public void AddBook(Book book)
        {
            Books.Add(book);
        }

        public void RegisterBorrower(Borrower borrower)
        {
            Borrowers.Add(borrower);
        }

        public bool BorrowBook(string isbn, string cardNumber)
        {
            var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed);
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == cardNumber);

            if (book != null && borrower != null)
            {
                borrower.BorrowBook(book);
                return true;
            }

            return false;
        }

        public bool ReturnBook(string isbn, string cardNumber)
        {
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == cardNumber);
            var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn);

            if (book != null)
            {
                borrower.ReturnBook(book);
                return true;
            }

            return false;
        }

        public List<string> ViewBooks()
        {
            return Books.Select(book =>
                $"{book.Title} by {book.Author} (ISBN: {book.ISBN}) - {(book.IsBorrowed ? "Borrowed" : "Available")}"
            ).ToList();
        }

        public List<string> ViewBorrowers()
        {
            return Borrowers.Select(borrower =>
                $"{borrower.Name} (Card: {borrower.LibraryCardNumber}) - Books: {string.Join(", ", borrower.BorrowedBooks.Select(b => b.Title))}"
            ).ToList();
        }
    }
}
