﻿using NUnit.Framework;
using LibraryManagementSystem;

namespace LibraryManagementSystem.Tests
{
    public class LibraryTests
    {
        private Library library;

        [SetUp]
        public void Setup()
        {
            library = new Library();
        }

        [Test]
        public void Test_AddBook()
        {
            var book = new Book("1984", "George Orwell", "123");
            library.AddBook(book);

            Assert.That(library.Books, Does.Contain(book));
        }

        [Test]
        public void Test_RegisterBorrower()
        {
            var borrower = new Borrower("Alice", "001");
            library.RegisterBorrower(borrower);

            Assert.That(library.Borrowers, Does.Contain(borrower));
        }
    }
}
