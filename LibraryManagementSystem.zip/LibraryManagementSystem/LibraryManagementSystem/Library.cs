﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LibraryManagementSystem
{
    public class Library
    {
        public List<Book> Books { get; private set; }
        public List<Borrower> Borrowers { get; private set; }

        public Library()
        {
            Books = new List<Book>();
            Borrowers = new List<Borrower>();
        }

        public void AddBook(Book book) => Books.Add(book);

        public void RegisterBorrower(Borrower borrower) => Borrowers.Add(borrower);

        public bool BorrowBook(string isbn, string libraryCardNumber)
        {
            var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed);
            var borrower = Borrowers.FirstOrDefault(br => br.LibraryCardNumber == libraryCardNumber);

            if (book != null && borrower != null)
            {
                borrower.BorrowBook(book);
                return true;
            }
            return false;
        }

        public bool ReturnBook(string isbn, string libraryCardNumber)
        {
            var borrower = Borrowers.FirstOrDefault(br => br.LibraryCardNumber == libraryCardNumber);
            var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn);

            if (book != null)
            {
                borrower.ReturnBook(book);
                return true;
            }
            return false;
        }

        public List<string> ViewBooks()
        {
            return Books.Select(b =>
                $"{b.Title} by {b.Author} (ISBN: {b.ISBN}) - {(b.IsBorrowed ? "Borrowed" : "Available")}")
                .ToList();
        }

        public List<string> ViewBorrowers()
        {
            return Borrowers.Select(b =>
                $"{b.Name} (Card: {b.LibraryCardNumber}) - Borrowed: {string.Join(", ", b.BorrowedBooks.Select(bb => bb.Title))}")
                .ToList();
        }
    }
}
