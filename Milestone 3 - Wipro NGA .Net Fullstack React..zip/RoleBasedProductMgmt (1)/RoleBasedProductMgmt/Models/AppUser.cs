
using Microsoft.AspNetCore.Identity;

namespace RoleBasedProductMgmt.Models
{
    public class AppUser : IdentityUser
    {
        // Add extra profile fields if needed
    }
}
