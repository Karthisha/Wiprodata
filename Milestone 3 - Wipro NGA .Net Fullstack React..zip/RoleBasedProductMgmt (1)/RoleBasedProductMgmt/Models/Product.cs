
using System.ComponentModel.DataAnnotations;

namespace RoleBasedProductMgmt.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string Name { get; set; } = string.Empty;

        // Encrypted price at rest, via Data Protection API
        [Required]
        public string PriceEncrypted { get; set; } = string.Empty;
    }

    public class ProductVm
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string Name { get; set; } = string.Empty;

        [Range(0.01, 100000000)]
        public decimal Price { get; set; }
    }
}
