﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RoleBasedProductMgmt.Data;
using RoleBasedProductMgmt.Models;
using RoleBasedProductMgmt.Services;

namespace RoleBasedProductMgmt.Controllers
{
    [Authorize(Roles = "Admin,Manager")]
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly ProductProtectionService _protector;

        public ProductController(ApplicationDbContext db, ProductProtectionService protector)
        {
            _db = db;
            _protector = protector;
        }

        public async Task<IActionResult> Index()
        {
            var items = await _db.Products.AsNoTracking().ToListAsync();
            var list = items.Select(p => new ProductVm
            {
                Id = p.Id,
                Name = p.Name,
                Price = _protector.DecryptPrice(p.PriceEncrypted)
            }).ToList();

            return View("ProductList", list);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Create() => View("CreateProduct", new ProductVm());

        [HttpPost, Authorize(Roles = "Admin"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductVm vm)
        {
            if (!ModelState.IsValid) return View("CreateProduct", vm);

            var entity = new Product
            {
                Name = vm.Name,
                PriceEncrypted = _protector.EncryptPrice(vm.Price)
            };
            _db.Products.Add(entity);
            await _db.SaveChangesAsync();
            TempData["Msg"] = $"Product \"{vm.Name}\" has been successfully created!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> Edit(int id)
        {
            var p = await _db.Products.FindAsync(id);
            if (p == null) return NotFound();
            var vm = new ProductVm
            {
                Id = p.Id,
                Name = p.Name,
                Price = _protector.DecryptPrice(p.PriceEncrypted)
            };
            return View("EditProduct", vm);
        }

        [HttpPost, Authorize(Roles = "Admin,Manager"), ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductVm vm)
        {
            if (!ModelState.IsValid) return View("EditProduct", vm);
            var p = await _db.Products.FindAsync(vm.Id);
            if (p == null) return NotFound();

            p.Name = vm.Name;
            p.PriceEncrypted = _protector.EncryptPrice(vm.Price);
            await _db.SaveChangesAsync();
            TempData["Msg"] = $"Product \"{vm.Name}\" has been successfully updated!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize] // allow both Admin & Manager in, then handle role manually
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            // If Manager tries to delete → redirect with reason
            if (User.IsInRole("Manager"))
            {
                return RedirectToAction("AccessDenied", "Account", new { reason = "delete" });
            }

            if (!User.IsInRole("Admin"))
            {
                return RedirectToAction("AccessDenied", "Account");
            }

            var p = await _db.Products.FindAsync(id);
            if (p == null) return NotFound();

            _db.Remove(p);
            await _db.SaveChangesAsync();
            TempData["Msg"] = $"Product \"{p.Name}\" deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
