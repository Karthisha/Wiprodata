
using System.Globalization;
using Microsoft.AspNetCore.DataProtection;

namespace RoleBasedProductMgmt.Services
{
    public class ProductProtectionService
    {
        private readonly IDataProtector _protector;
        public ProductProtectionService(IDataProtectionProvider provider)
        {
            _protector = provider.CreateProtector("ProductPriceProtector.v1");
        }

        public string EncryptPrice(decimal price)
        {
            // Store using invariant culture to avoid locale issues
            var serialized = price.ToString("G", CultureInfo.InvariantCulture);
            return _protector.Protect(serialized);
        }

        public decimal DecryptPrice(string encrypted)
        {
            var raw = _protector.Unprotect(encrypted);
            if (decimal.TryParse(raw, NumberStyles.Any, CultureInfo.InvariantCulture, out var value))
                return value;
            throw new InvalidOperationException("Unable to parse protected price.");
        }
    }
}
