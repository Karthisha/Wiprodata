using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RoleBasedProductMgmt.Data;
using RoleBasedProductMgmt.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(
        Path.Combine(builder.Environment.ContentRootPath, "DataProtection-Keys")));

builder.Services.AddIdentity<AppUser, IdentityRole>(options =>
{
    options.Password.RequiredLength = 8;
    options.Password.RequireDigit = false;
    options.Password.RequireNonAlphanumeric = true; // special char
    options.Password.RequireUppercase = true;
    options.Password.RequireLowercase = true;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    // Allow query string ?reason=delete to show specific messages
    options.AccessDeniedPath = "/Account/AccessDenied";
});

builder.Services.AddControllersWithViews();

// Register ProductProtection service
builder.Services.AddScoped<RoleBasedProductMgmt.Services.ProductProtectionService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// Seed roles and users and ensure DB created
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<ApplicationDbContext>();
    var userManager = services.GetRequiredService<UserManager<AppUser>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

    // Create DB if missing (no migrations required)
    context.Database.EnsureCreated();

    // Seed roles
    string[] roles = new[] { "Admin", "Manager" };
    foreach (var role in roles)
    {
        if (!await roleManager.RoleExistsAsync(role))
        {
            await roleManager.CreateAsync(new IdentityRole(role));
        }
    }

    // Seed users
    async Task EnsureUser(string username, string password, string role)
    {
        var user = await userManager.FindByNameAsync(username);
        if (user == null)
        {
            user = new AppUser
            {
                UserName = username,
                Email = $"{username}@example.com",
                EmailConfirmed = true
            };
            var createResult = await userManager.CreateAsync(user, password);
            if (!createResult.Succeeded)
            {
                var reason = string.Join(";", createResult.Errors.Select(e => e.Description));
                throw new Exception($"Failed to create user {username}: {reason}");
            }
        }
        if (!await userManager.IsInRoleAsync(user, role))
        {
            await userManager.AddToRoleAsync(user, role);
        }
    }

    await EnsureUser("admin", "Admin@123", "Admin");
    await EnsureUser("manager1", "Manager@123", "Manager");

    // Seed a sample product
    if (!context.Products.Any())
    {
        var protector = services.GetRequiredService<RoleBasedProductMgmt.Services.ProductProtectionService>();
        var p = new RoleBasedProductMgmt.Models.Product
        {
            Name = "Laptop",
            PriceEncrypted = protector.EncryptPrice(1200m)
        };
        context.Products.Add(p);
        await context.SaveChangesAsync();
    }
}

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();
