﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample1
{
    internal interface ITraining
    {
        //string Company { get; set; }
        void Name();
        void Email();
    }
}
