﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionLibrary
{
    public class Operations
    {
        public string MileStone1()
        {
            return "MileStone 1 is on Core Concepts...";
        }

        public string MileStone2()
        {
            return "MileStone 2 on Asp.net MVC and Rajor...";
        }
    }
}
