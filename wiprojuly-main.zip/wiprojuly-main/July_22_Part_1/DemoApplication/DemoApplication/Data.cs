﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApplication
{
    internal class Data
    {
        static void Main()
        {
            Demo demo = new Demo();
            demo.Greeting();
            demo.Company();
           
        }
    }
}
