﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class ConstExample
    {
       static void Main()
        {
            const string company = "Wipro";
            const int month = 7;
            Console.WriteLine("Company is  " +company);
            Console.WriteLine("Month is  " +month);
        }
        
    }
}
