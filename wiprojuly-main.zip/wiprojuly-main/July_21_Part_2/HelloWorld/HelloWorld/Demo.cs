﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Demo
    {
        static void Main()
        {
            Data data = new Data();
            data.Greeting(); 
            data.Company();
           
        }
    }
}
