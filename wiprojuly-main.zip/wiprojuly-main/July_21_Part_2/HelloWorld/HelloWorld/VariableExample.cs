﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class VariableExample
    {
        static void Main()
        {
            int a = 12;
            string name = "Prasanna";
            double basic = 84235.22;
            Console.WriteLine("A value is  " +a);
            Console.WriteLine("Name is  " +name);
            Console.WriteLine("Salary is  " +basic);
        }
    }
}
