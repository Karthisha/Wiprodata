﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Quiz3
    {
        static void Main()
        {
            char ch = 'A';
            ch++;
            Console.WriteLine(ch);
        }
    }
}
