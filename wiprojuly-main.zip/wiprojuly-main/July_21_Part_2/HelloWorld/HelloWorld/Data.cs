﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Data
    {
        public void Greeting()
        {
            Console.WriteLine("Welcome to Dotnet Training...");
        }

        internal void Company()
        {
            Console.WriteLine("Company is Wipro...");
        }

        private void Trainer()
        {
            Console.WriteLine("Trainer is Prasanna Pappu...");
        }
    }
}
