﻿using Microsoft.AspNetCore.DataProtection;

namespace ProductManagementSystem.Services
{
    public class DataProtectionService
    {
        private readonly IDataProtector _protector;

        public DataProtectionService(IDataProtectionProvider provider)
        {
            _protector = provider.CreateProtector("ProductManagement.PriceProtection");
        }

        public string ProtectPrice(decimal price)
        {
            return _protector.Protect(price.ToString());
        }

        public decimal UnprotectPrice(string protectedPrice)
        {
            var unprotectedPrice = _protector.Unprotect(protectedPrice);
            return decimal.Parse(unprotectedPrice);
        }
    }
}
