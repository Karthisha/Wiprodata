using OnlineShoppingPlatform.Models;

namespace OnlineShoppingPlatform.Services
{
    public interface IAuthService
    {
        Task<User> Register(string email, string password, string role);
        Task<User> Login(string email, string password);
    }
}
