using System.ComponentModel.DataAnnotations;

namespace OnlineShoppingPlatform.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        [Range(0.01, 99999.99)]
        public decimal Price { get; set; }
    }
}
