using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SecureDbWebApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SecureController : ControllerBase
    {
        [Authorize]
        [HttpGet("user")]
        public IActionResult UserResource()
        {
            return Ok("Secure data for authenticated users.");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("admin")]
        public IActionResult AdminResource()
        {
            return Ok("Secure data for Admin users only.");
        }
    }
}
