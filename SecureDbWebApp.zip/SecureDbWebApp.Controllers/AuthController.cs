using Microsoft.AspNetCore.Mvc;
using SecureDbWebApp.Services;
using SecureDbWebApp.Models;
using SecureDbWebApp.Utilities;

namespace SecureDbWebApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly Data.AppDbContext _context;

        public AuthController(IAuthService authService, Data.AppDbContext context)
        {
            _authService = authService;
            _context = context;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] User user)
        {
            if (_context.Users.Any(u => u.Username == user.Username))
                return BadRequest("User already exists");

            user.PasswordHash = PasswordHasher.HashPassword(user.PasswordHash);
            _context.Users.Add(user);
            _context.SaveChanges();

            return Ok("User registered successfully");
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User loginUser)
        {
            var token = _authService.Authenticate(loginUser.Username, loginUser.PasswordHash);
            if (token == null)
                return Unauthorized("Invalid credentials");

            return Ok(new { token });
        }
    }
}
