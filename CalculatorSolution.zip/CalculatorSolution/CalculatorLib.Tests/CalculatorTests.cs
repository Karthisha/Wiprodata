﻿using NUnit.Framework;
using CalculatorLib;
using System;

namespace CalculatorLib.Tests
{
    public class CalculatorTests
    {
        private Calculator calculator;

        [SetUp]
        public void Setup()
        {
            calculator = new Calculator();
        }

        [Test]
        public void Add_ReturnsCorrectSum()
        {
            Assert.AreEqual(5, calculator.Add(2, 3));
        }

        [Test]
        public void Subtract_ReturnsCorrectResult()
        {
            Assert.AreEqual(2, calculator.Subtract(5, 3));
        }

        [Test]
        public void Multiply_ReturnsCorrectResult()
        {
            Assert.AreEqual(6, calculator.Multiply(2, 3));
        }

        [Test]
        public void Divide_ReturnsCorrectResult()
        {
            Assert.AreEqual(2, calculator.Divide(6, 3));
        }

        [Test]
        public void Divide_ByZero_ThrowsException()
        {
            Assert.Throws<DivideByZeroException>(() => calculator.Divide(10, 0));
        }
    }
}
