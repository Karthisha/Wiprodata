﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLibrary1;

namespace CalculatorLibrary1
{
    internal class CalculationClient
    {
        static void Main(string[] args, Calculator calculator) {
            CalculationClient calculation = calculator;
        int a, b;
            Console.WriteLine("Enter 2 Numbers  ");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
        }

        public static implicit operator CalculationClient(Calculator v)
        {
            throw new NotImplementedException();
        }
    }
}
